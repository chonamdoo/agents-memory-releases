import json,os,subprocess
from pathlib import Path
import pytest

@pytest.mark.parametrize('arguments,expected',[
 (['--provider','local-llm','--judge-host','claude','--client','omp','--project','/tmp/project with space','--virtual-linux'],['--provider','claude','--client','omp','--project','/tmp/project with space']),
 (['--provider=local-llm','--judge-host=codex','--client','codex'],['--provider','codex','--client','codex']),
 (['--provider','jev','--client','claude-plugin'],['--provider','jev','--client','claude-plugin']),
])
def test_legacy_arguments_reach_the_common_installer_without_shell_splitting(tmp_path,arguments,expected):
 shim=tmp_path/'curl';shim.write_text('''#!/usr/bin/env python3
import sys
from pathlib import Path
args=sys.argv[1:]
assert any('/v1.0.8/distribution/server/install-unified.sh' in a for a in args)
Path(args[args.index('-o')+1]).write_text('#!/bin/bash\\npython3 -c \\'import json,sys; print(json.dumps(sys.argv[1:]))\\' "$@"\\n')
''');shim.chmod(0o700)
 result=subprocess.run(['/bin/bash','/workspace/work/cloud-release-ready/distribution/mcp-local/install.sh',*arguments],env=dict(os.environ,PATH=str(tmp_path)+os.pathsep+os.environ['PATH']),stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=5)
 assert result.returncode==0,result.stderr
 assert json.loads(result.stdout)==expected
