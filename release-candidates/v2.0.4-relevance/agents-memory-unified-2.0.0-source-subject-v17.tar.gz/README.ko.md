# Agents Memory runtime 2.0.0

이 번들은 Core2.0.0과 SDK2.0.0의 수정 후보를 포함합니다. MCP 연결 패키지는2.0.4입니다. 배포 상태와 검증 범위는 https://github.com/chonamdoo/agents-memory-releases/releases 에서 확인하세요. 번들의 존재 자체는 정식 검증 통과를 의미하지 않습니다.

설치·업데이트: https://github.com/chonamdoo/agents-memory-releases#설치
기존 키·데이터베이스·모델·미전송 작업은 플러그인 캐시 밖에서 보존합니다. 모델 companion은 기존 v2.0.0 자산과 SHA256SUMS를 사용합니다. 원문 독립 검색과 Native recall은 서로 다른 도구이며, 원문은 미검증 참고 근거입니다.
