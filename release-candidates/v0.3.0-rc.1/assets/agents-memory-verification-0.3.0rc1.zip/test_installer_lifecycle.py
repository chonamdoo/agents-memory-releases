"""Opaque credential preservation and actual cold DB/MCP startup; synthetic only."""
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

import pytest
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
from agents_memory_collab.client import Remote,Replica

ROOT=Path(__file__).parent
PREFIX=ROOT/'cold-install'
PROJECT=ROOT/'cold-project'
BUNDLE=ROOT/'publish/agents-memory-unified-0.3.0rc1'
SETUP=Path('/workspace/work/cloud-release-ready/distribution/server/unified_setup.py')
BASE=PREFIX/'current/venv/bin/python'


def load():
 spec=importlib.util.spec_from_file_location('qa_unified_setup',SETUP);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


@pytest.mark.asyncio
async def test_update_preserves_credentials_data_and_host_configs_then_mcp_restarts_db():
 setup=load()
 connection=PREFIX/'client/local/connection.json';state=PREFIX/'client/local/replica.sqlite'
 # Credential bytes remain only inside this application process, never in evidence.
 sensitive=[PREFIX/'settings/jev-credential.json',PREFIX/'settings/unified-manager.json',connection]
 before=[p.read_bytes() for p in sensitive]
 config_before=(PREFIX/'settings/unified.json').read_bytes()
 hosts=[PROJECT/'.mcp.json',PROJECT/'.codex/config.toml',PROJECT/'.omp/mcp.json',PROJECT/'.claude/settings.local.json',PROJECT/'.codex/hooks.json',PROJECT/'.omp/extensions/agents-memory-cloud.ts']
 host_before=[p.read_bytes() for p in hosts]
 saved=json.loads(connection.read_text());replica=Replica(state,Remote(saved['url'],saved['token'],timeout=120))
 staged=replica.stage(PROJECT.name,'The synthetic lifecycle service requires four reviewers.')
 replica.close()
 with (ROOT/'update-preservation-private.log').open('wb') as log:
  result=await asyncio.to_thread(subprocess.run,[str(BASE),'-I',str(SETUP),'install','--prefix',str(PREFIX),'--bundle',str(BUNDLE),'--client','all','--project',str(PROJECT)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 assert result.returncode==0,'Inspect private installer log'
 assert all(p.read_bytes()==old for p,old in zip(sensitive,before))
 assert (PREFIX/'settings/unified.json').read_bytes()==config_before
 assert all(p.read_bytes()==old for p,old in zip(hosts,host_before))
 replica=Replica(state,Remote(saved['url'],saved['token'],timeout=120))
 assert any(x['id']==staged['memory_id'] for x in replica.list_memories());replica.close()
 # Stop both services of this explicitly owned test install; no real user DB.
 await asyncio.to_thread(setup.stop,PREFIX)
 _,helper,_=setup.read_settings(PREFIX)
 await asyncio.to_thread(helper.stop_native_database,PREFIX)
 assert setup.owned_pid(PREFIX,helper) is None
 started=time.monotonic()
 parameters=StdioServerParameters(command=str(PREFIX/'bin/unified-python'),args=['-m','agents_memory_collab.cli','mcp','--connection',str(connection),'--state',str(state),'--project',PROJECT.name],env=dict(os.environ))
 async with stdio_client(parameters) as (read,write),ClientSession(read,write) as session:
  await session.initialize();initialize_seconds=time.monotonic()-started
  for _ in range(240):
   status=json.loads((await session.call_tool('setup_status',{})).content[0].text)
   if status['server_ready']:break
   await asyncio.sleep(.5)
  else:raise AssertionError('Installed launcher failed to restart the owned DB and service')
  assert status['version']=='0.3.0rc1'
  recalled=json.loads((await session.call_tool('recall',{'query':'lifecycle reviewers','project':PROJECT.name})).content[0].text)
  assert any('four reviewers' in x['text'] for x in recalled['memories'])
  assert setup.owned_pid(PREFIX,helper) is not None
 (ROOT/'installer-lifecycle.json').write_text(json.dumps({'synthetic_only':True,'credentials_unchanged':True,'provider_model_url_ports_unchanged':True,'all_three_host_configs_and_hooks_unchanged':True,'pending_intent_preserved_and_processed':True,'owned_db_and_service_restart_on_mcp_connection':True,'mcp_initialize_seconds':round(initialize_seconds,3),'version':status['version']},indent=2)+'\n')
