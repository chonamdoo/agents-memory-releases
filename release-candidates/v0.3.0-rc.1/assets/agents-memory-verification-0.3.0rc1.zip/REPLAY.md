# 再実行 / 재실행

These are exact commands for the retained isolated Linux QA workspace. They are
not installation commands for a user's live server. No real user memories were used.
Outside this workspace, replace the Python/PG/E5/CLI and QA paths in the harnesses;
create an isolated PostgreSQL cluster first. The harnesses create only synthetic
`product_gen_*` databases, but do not point their port at a production cluster.

Versions/hashes: see SNAPSHOT.json, ASSETS.json in the release bundle, and both
BUILD-core JSON files. Public source commit and private core commit are recorded
separately. The original private policy source is not part of this archive.

```bash
QA=/workspace/work/product-release-20261105
PUBLIC=/workspace/work/cloud-release-ready/distribution/server
QA_PYTHON=/workspace/work/cloud-fable-review-20261104/venv/bin/python
# A new explicit private credential file is required after QA cleanup.
# Application code reads it; never print it or place the value on the command line.
export AM_MEMORY_JEV_KEY_FILE=/absolute/private/jev_api_key
export AM_INSTALLED_SERVER_PYTHON="$QA/cold-install/unified-current/gateway/bin/python"
export PYTHONPATH="$PUBLIC/src"
"$QA_PYTHON" -m pytest "$QA/test_product_generation.py" -q
AM_QA_ONLY_REJECTION=1 "$QA_PYTHON" -m pytest "$QA/test_product_generation.py" -k 'claude or codex or (jev and local)' -q
"$QA_PYTHON" -m pytest "$QA/test_installer_lifecycle.py" "$QA/test_thin_client.py" -q

AM_FRESH_CLIENT_PYTHON="$AM_INSTALLED_SERVER_PYTHON" AM_NATIVE_HOST_CHECK=1 \
  "$QA_PYTHON" -m pytest "$QA/native-hosts/test_runtime_automation.py" -q -s

export AM_COLLAB_TEST_DSN=postgresql://agent@127.0.0.1:36123/unified_synthetic
export AM_COLLAB_TEST_DATA_DIR=/workspace/work/unified-memory-20261105/pgdata
export AM_UNIFIED_TEST_RECEIPT=/workspace/work/unified-memory-20261105/runtime.json
export AM_COLLAB_TEST_E5=/workspace/work/native-pg/jev-e2e/runtime/current/payload/models/e5-small
export AM_COLLAB_TEST_E5_MANIFEST="$PUBLIC/e5-assets.sha256.json"
export AM_COLLAB_TEST_PROXY=/workspace/work/cloud-mac-path-fix-qa/legacy-proxy
export AM_COLLAB_TEST_WHEEL="$QA/dist-rc1-final/agents_memory_collaboration-0.3.0rc1-py3-none-any.whl"
export AM_TEST_UNIFIED_PLUGIN=/workspace/work/cloud-release-ready/plugins/agents-memory-unified
export AM_TEST_UNIFIED_INSTALL="$QA/cold-install"
# The common-processor regression needs its private module, available either in
# the release core wheel installed in QA Python or the owner's private checkout.
PYTHONPATH="$PUBLIC/src:/workspace/agents-memory/src" "$QA_PYTHON" -m pytest "$PUBLIC/tests" -q
```

The product's Hindsight Python is the pinned 3.13 venv in the harness; it separately
verifies all 366 source-file hashes. QA Python and the installed gateway Python
are not interchangeable. Installed product child processes have PYTHONPATH removed.

Provider execution requires Claude/Codex login on the engine host; no OAuth copies
are in these artifacts. OMP's probe checks event capture/context with an intentionally
invalid outer-model key. Its final model reply is not a passing claim.

The lifecycle harness contains hardcoded synthetic prefix/project paths. It stops
and starts that owned QA DB and service and runs an update. Do not change those to
actual user installations when replaying. Keys and user data were excluded from
this archive. QA's actual Jev credential copies are removed after validation, so
replay needs a fresh authorized key file and the saved QA install's Jev file restored
through application setup. A missing key must produce setup failure, not a bypass.

Mac dependency resolution was a pip cross-platform download with --require-hashes;
it is not Mac execution. Native Windows, Windows-host WSL2, GUI first trust,
OS reboot/login/hibernation, and existing-user-data migration are not proven here.
