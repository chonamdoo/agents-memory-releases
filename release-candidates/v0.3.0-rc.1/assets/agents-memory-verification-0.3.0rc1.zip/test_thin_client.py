import asyncio
import importlib.metadata
import json
import os
from pathlib import Path
from uuid import uuid4

import pytest
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT=Path(__file__).parent

@pytest.mark.asyncio
async def test_thin_remote_mcp_uses_server_processing_without_jev_key_or_local_engine():
 python=ROOT/'thin-client/venv/bin/python'
 connection=ROOT/'thin-client/personal/connection.json'
 env={k:v for k,v in os.environ.items() if k not in {'AM_MEMORY_JEV_KEY_FILE','HINDSIGHT_API_MEMORY_ADMISSION_API_KEY','PYTHONPATH'}}
 parameters=StdioServerParameters(command=str(python),args=['-m','agents_memory_collab.cli','mcp','--connection',str(connection),'--state',str(ROOT/'thin-client/personal/replica.sqlite'),'--project','thin-project'],env=env)
 async with stdio_client(parameters) as (read,write),ClientSession(read,write) as session:
  await session.initialize()
  status=json.loads((await session.call_tool('setup_status',{})).content[0].text)
  assert status['server_ready'] and status['version']=='0.3.0rc1'
  received=json.loads((await session.call_tool('sync_retain',{'op_id':str(uuid4()),'memory_id':str(uuid4()),'project':'thin-project','text':'The synthetic thin client service requires six reviewers.'})).content[0].text)
  assert received['state']=='received' and not received['memory_ready']
  for _ in range(100):
   value=json.loads((await session.call_tool('recall',{'query':'thin client reviewers','project':'thin-project'})).content[0].text)
   if any('six reviewers' in x['text'] for x in value['memories']):break
   await asyncio.sleep(.2)
  else:raise AssertionError('Actual thin client background processing did not complete')
  assert value['source']=='server' and value['semantic']
 (ROOT/'thin-client.json').write_text(json.dumps({'synthetic_only':True,'installed_version':'0.3.0rc1','client_has_no_jev_key':True,'actual_stdio_background_drain_and_remote_recall':True,'three_host_configs_generated':True},indent=2)+'\n')
