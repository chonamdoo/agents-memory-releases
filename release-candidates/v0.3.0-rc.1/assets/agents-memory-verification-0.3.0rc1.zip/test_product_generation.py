"""Actual product runtime, selected subscription CLI and two durable replicas."""
import asyncio
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
from uuid import UUID,uuid4

import asyncpg
import pytest

from agents_memory_collab.client import Remote,Replica
from agents_memory_collab.models import Invite,ShareMapping
from agents_memory_collab.store import Store

ROOT=Path(__file__).parent
PG=Path('/workspace/work/native-pg/e2e/runtime/database/18.6.1-vector0.8.7/bin')
MODEL=Path('/workspace/work/native-pg/jev-e2e/runtime/current/payload/models/e5-small')
PUBLIC=Path('/workspace/work/cloud-release-ready/distribution/server')
PYTHON=Path(sys.executable)


def port():
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));return sock.getsockname()[1]


@pytest.mark.asyncio
@pytest.mark.parametrize('provider,mode',[('claude','local'),('codex','personal-server'),('jev','local'),('jev','personal-server'),('jev','team-server'),('jev','company-server')])
async def test_real_product_pipeline(provider,mode,tmp_path):
    database='product_gen_'+uuid4().hex[:10]
    subprocess.run([str(PG/'createdb'),'-h','127.0.0.1','-p','36123',database],check=True,capture_output=True)
    dsn='postgresql://agent@127.0.0.1:36123/'+database
    gateway,backend=port(),port();url=f'http://127.0.0.1:{gateway}'
    work=tmp_path/'cli-work';work.mkdir()
    executable,model={'claude':('/workspace/work/claude-cli/node_modules/.bin/claude','claude-fable-5-1'),
                      'codex':('/opt/codex/bin/codex','gpt-6.1-terra'), 'jev':('/bin/false','jev-1.14.0')}[provider]
    env=dict(os.environ,AM_COLLAB_DATABASE_URL=dsn,AM_MEMORY_PROVIDER=provider,AM_MEMORY_MODEL=model,
             AM_MEMORY_EXECUTABLE=executable,AM_MEMORY_WORKDIR=str(work),
    PYTHONPATH='/workspace/agents-memory/src:'+str(PUBLIC/'src'))
    installed_python=os.environ.get('AM_INSTALLED_SERVER_PYTHON')
    if installed_python:env.pop('PYTHONPATH',None)
    command=[installed_python or str(PYTHON),'-m','agents_memory.runtime_launcher' if installed_python else 'agents_memory.unified_runtime','--mode',mode,'--hindsight-python',
        '/workspace/work/native-pg/jev-e2e/runtime/current/venv/bin/python','--gateway-python',installed_python or str(PYTHON),
        '--e5-dir',str(MODEL),'--e5-manifest',str(PUBLIC/'e5-assets.sha256.json'),
        '--port',str(gateway),'--hindsight-port',str(backend),'--public-url',url]
    log=(tmp_path/'runtime-private.log').open('wb')
    process=subprocess.Popen(command,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    a=b=None
    evidence={'provider':provider,'mode':mode,'database':database,'synthetic_only':True,'passed':False,'phases':[]}
    operator=Store(dsn)
    try:
        for _ in range(1200):
            assert process.poll() is None,'Product runtime exited; inspect private log'
            try:
                import urllib.request
                def health():
                    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(url+'/healthz',timeout=1) as response:return json.load(response)
                status=await asyncio.to_thread(health)
                if status.get('ready'):break
            except OSError:pass
            await asyncio.sleep(.1)
        else:raise AssertionError('Product startup deadline')
        assert status['memory']['generation_enabled'] is (provider != 'jev')
        assert status['memory']['integration_enabled'] is True
        await operator.open()
        key=await operator.create_account('Synthetic product owner')
        actor=await operator.authenticate(key['token'])
        second=await operator.create_device(actor,'Synthetic product PC B',True)
        a=Replica(tmp_path/'a.sqlite',Remote(url,key['token'],timeout=300))
        b=Replica(tmp_path/'b.sqlite',Remote(url,second['token'],timeout=300))
        await asyncio.to_thread(a.connect);await asyncio.to_thread(b.connect)
        if os.environ.get('AM_QA_ONLY_REJECTION') == '1':
            staged=a.stage('Polaris','Thanks for your help. Goodbye!')
            await asyncio.to_thread(a.cycle);await asyncio.to_thread(b.cycle)
            assert b.list_memories()==[]
            assert await operator.pool.fetchval('SELECT count(*) FROM am_collab.memories WHERE user_id=$1 AND processing_state=\'ready\'',actor.user_id)==0
            status=a.status()
            assert all(x['status']=='needs_review' for x in status['pending'])
            recalled=await asyncio.to_thread(b.remote.request,'/v1/recall',{'query':'help goodbye','project':'Polaris'})
            assert recalled['memories']==[]
            evidence['phases'].append('ephemeral_input_never_becomes_final_memory')
            evidence['passed']=True
            return
        # The actual API creates prepared work, indexes, waits for consolidation,
        # publishes current revision, and returns generated recall to another PC.
        source='The synthetic Polaris release process requires two reviewers.'
        staged=a.stage('Polaris',source,session_id='synthetic-A',source_id='synthetic-source-A')
        mid=staged['memory_id'];assert staged['memory_ready'] is False
        await asyncio.to_thread(a.cycle);await asyncio.to_thread(b.cycle)
        rows=b.list_memories();assert len(rows)==1 and rows[0]['text']==source
        recall=await asyncio.to_thread(b.remote.request,'/v1/recall',{'query':'Polaris release reviewer count','project':'Polaris'})
        assert recall['generation_enabled'] is (provider != 'jev')
        assert recall['memories']
        assert any('two' in x['text'].lower() or '2' in x['text'] for x in recall['memories'])
        assert all(x['derived'] and x['sources'] for x in recall['memories'])
        evidence['phases'].append('selected_cli_to_product_hindsight_to_other_pc_generated_recall')
        evidence['recall']=recall
        corroborating=a.stage('Polaris','The synthetic Polaris team requires two reviewers to approve each release.',
                              session_id='synthetic-B',source_id='synthetic-source-B')
        await asyncio.to_thread(a.cycle);await asyncio.to_thread(b.cycle)
        recall=await asyncio.to_thread(b.remote.request,'/v1/recall',{'query':'Polaris reviewer approval policy','project':'Polaris'})
        assert any(len(x['sources'])==2 for x in recall['memories']),'product did not return the two-source integration'
        evidence['two_source_recall']=recall
        evidence['phases'].append('automatic_cross_source_product_integration')
        # Retry the durable original operation; do not publish a second revision.
        original=await operator.pool.fetchval('SELECT original FROM am_collab.memory_jobs WHERE user_id=$1 AND op_id=$2',actor.user_id,UUID(staged['op_id']))
        await asyncio.to_thread(a.remote.request,'/v1/sync/ops',{'operations':[json.loads(original)]})
        assert await operator.pool.fetchval('SELECT count(*) FROM am_collab.changes WHERE user_id=$1',actor.user_id)==2
        # Private memory is not automatically shared. Current sharing/membership
        # must guard generated observations as well as source records.
        otherkey=await operator.create_account('Synthetic team reader')
        reader=await operator.authenticate(otherkey['token'])
        team=UUID((await operator.create_team(actor,'Synthetic team'))['id'])
        project=UUID((await operator.create_project(actor,team,'Polaris'))['id'])
        invite=await operator.invite(actor,team,Invite(projects=[project]));await operator.accept(reader,invite['invite'])
        # Use existing Store methods with the actual product engine adapter for
        # precise grant cases; HTTP personal recall above is independent evidence.
        from agents_memory_collab.memory_engine import HindsightEngine
        class ReadOnlyProcessor:
            contract='agents-memory-grounded-v1'
            async def process(self,source):raise AssertionError('All inference must run through the real product gateway')
        operator.memory_engine=HindsightEngine(f'http://127.0.0.1:{backend}',ReadOnlyProcessor(),generative=True,source_preserving=provider=='jev')
        assert (await operator.search(reader,'reviewer',team=team))['memories']==[]
        await operator.sharing(actor,team,[ShareMapping(source_project='Polaris',project_id=project)])
        assert (await operator.search(reader,'reviewer',team=team))['memories']
        assert (await operator.brief(reader,team,project))['items']
        await operator.sharing(actor,team,[])
        assert (await operator.search(reader,'reviewer',team=team))['memories']==[]
        assert (await operator.brief(reader,team,project))['items']==[]
        evidence['phases'].append('generated_team_search_brief_and_unshare')
        # An actual revision edit, not a new corrective document.
        updated='The synthetic Polaris release process now requires three reviewers instead of two.'
        a.stage('Polaris',updated,memory_id=mid,base_revision=1)
        await asyncio.to_thread(a.cycle);await asyncio.to_thread(b.cycle)
        recall=await asyncio.to_thread(b.remote.request,'/v1/recall',{'query':'current Polaris reviewers','project':'Polaris'})
        assert any('three' in x['text'].lower() or '3' in x['text'] for x in recall['memories'])
        assert all(s['revision']==(2 if s['id']==mid else 1) for x in recall['memories'] for s in x['sources'])
        evidence['phases'].append('actual_revision_edit_and_current_derived_provenance')
        a.stage('Polaris',None,memory_id=mid,base_revision=2,deleted=True)
        await asyncio.to_thread(a.cycle);await asyncio.to_thread(b.cycle)
        survivor=await asyncio.to_thread(b.remote.request,'/v1/recall',{'query':'Polaris reviewer policy','project':'Polaris'})
        assert survivor['memories'], 'deleting one source must preserve the other source recall'
        assert all(s['id'] != mid for x in survivor['memories'] for s in x['sources'])
        evidence['phases'].append('delete_one_source_and_reintegrate_surviving_evidence')
        a.stage('Polaris',None,memory_id=corroborating['memory_id'],base_revision=1,deleted=True)
        await asyncio.to_thread(a.cycle);await asyncio.to_thread(b.cycle)
        assert b.list_memories()==[]
        recall=await asyncio.to_thread(b.remote.request,'/v1/recall',{'query':'Polaris reviewer policy','project':'Polaris'})
        assert recall['memories']==[]
        evidence['phases'].append('delete_source_and_generated_recall')
        evidence['passed']=True
    finally:
        if a:a.close()
        if b:b.close()
        await operator.close()
        process.terminate()
        try:process.wait(timeout=20)
        except subprocess.TimeoutExpired:process.kill();process.wait()
        log.close()
        evidence['private_log']=str(tmp_path/'runtime-private.log')
        (ROOT/(provider+'-'+mode+('-rejection' if os.environ.get('AM_QA_ONLY_REJECTION') else '-product')+'.json')).write_text(json.dumps(evidence,indent=2,default=str)+'\n')
