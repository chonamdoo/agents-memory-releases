"""Actual combined runtime, generated three-host config, and stdio automation."""
import asyncio
from argparse import Namespace
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import urllib.request

import pytest
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from agents_memory_collab.client import Remote, Replica
from agents_memory_collab.setup import install, write_private
from agents_memory_collab.store import Store

ROOT=Path(__file__).parent
RUNTIME=json.loads((ROOT/'runtime.json').read_text())
PUBLIC=Path('/workspace/work/cloud-release-ready/distribution/server')
PRIVATE=Path('/workspace/agents-memory/src')
PYTHON=sys.executable
MODEL=Path('/workspace/work/native-pg/jev-e2e/runtime/current/payload/models/e5-small')
pytestmark=pytest.mark.asyncio

def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));return sock.getsockname()[1]


async def test_combined_runtime_generated_hooks_and_background_sync(tmp_path):
    port,internal=free_port(),free_port()
    url=f'http://127.0.0.1:{port}'
    env=dict(os.environ,AM_COLLAB_DATABASE_URL=RUNTIME['dsn'],AM_MEMORY_PROVIDER='jev',AM_MEMORY_MODEL='jev-1.14.0',
        PYTHONPATH=str(PRIVATE)+':'+str(PUBLIC/'src'))
    assert env.get('AM_MEMORY_JEV_KEY_FILE'), 'Explicit private Jev file is required'
    command=[PYTHON,'-m','agents_memory.unified_runtime','--mode','local',
        '--hindsight-python','/workspace/work/native-pg/jev-e2e/runtime/current/venv/bin/python',
        '--gateway-python',PYTHON,'--e5-dir',str(MODEL),'--e5-manifest',str(PUBLIC/'e5-assets.sha256.json'),
        '--port',str(port),'--hindsight-port',str(internal),'--public-url',url]
    with open(tmp_path/'runtime-private.log','wb') as log:
        process=subprocess.Popen(command,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    a=b=None
    try:
        def health():
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(url+'/healthz',timeout=1) as response:
                return json.load(response)
        for _ in range(600):
            assert process.poll() is None, 'Combined runtime exited; inspect private test log'
            try:
                status=await asyncio.to_thread(health)
                if status['ready']:break
            except OSError:pass
            await asyncio.sleep(.1)
        else:raise AssertionError('Combined runtime startup deadline')
        assert status['memory']['deployment_mode']=='local'
        operator=Store(RUNTIME['dsn'])
        await operator.open()
        try:key=await operator.create_account('Synthetic runtime automation')
        finally:await operator.close()
        manager=tmp_path/'manager.json'
        write_private(manager,json.dumps({'url':url,'token':key['token']}))
        project=tmp_path/'project';project.mkdir()
        subprocess.run(['git','init','--quiet',str(project)],check=True)
        args=Namespace(profile='local',client=['all'],root=tmp_path/'persistent',project=project,project_name='synthetic-automation',
            url=url,credential_file=manager,device_name='Synthetic automation PC',no_automatic_memory=False)
        client_python=Path(os.environ.get('AM_FRESH_CLIENT_PYTHON',PYTHON))
        if os.environ.get('AM_FRESH_CLIENT_PYTHON'):
            client_env=dict(env)
            client_env.pop('PYTHONPATH',None)
            completed=await asyncio.to_thread(subprocess.run,[str(client_python),'-m','agents_memory_collab.cli','setup',
                '--client','all','--root',str(args.root),'--profile','local','--project',str(project),
                '--project-name','synthetic-automation','--url',url,'--credential-file',str(manager)],
                env=client_env,capture_output=True,timeout=30)
            assert completed.returncode==0,'Fresh installed client setup failed'
            configured=json.loads(completed.stdout)
        else:
            configured=await asyncio.to_thread(install,args)
        assert configured['ready'] and len(configured['automation_files'])==3
        connection=tmp_path/'persistent/local/connection.json';state=tmp_path/'persistent/local/replica.sqlite'
        saved=json.loads(connection.read_text())
        assert saved['automatic_memory'] is True
        remote=Remote(url,saved['token'],timeout=150)
        a=Replica(state,remote)
        await asyncio.to_thread(a.connect)
        marker='The synthetic automation service uses verification marker AM_QA_9d7c_azure.'
        a.stage('synthetic-automation',marker)
        await asyncio.to_thread(a.cycle)
        a.close();a=None
        if os.environ.get('AM_NATIVE_HOST_CHECK')=='1':
            from native_host_probe import run_native, omp_probe
            native=await run_native(project,state,env)
            print('native host results',json.dumps(native))
            omp=await asyncio.to_thread(omp_probe,project,state,env)
            print('native OMP results',json.dumps(omp))
        event={'hook_event_name':'UserPromptSubmit','session_id':'synthetic-hook-session',
            'event_id':'synthetic-prompt-001','prompt':'The synthetic automation service requires two reviewers.'}
        for host in ('claude','codex','omp'):
            current=dict(event)
            if host=='omp':current['hook_event_name']='before_agent_start'
            command=[PYTHON,'-m','agents_memory_collab.automation','--connection',str(connection),'--state',str(state),
                '--project','synthetic-automation','--host',host]
            response=await asyncio.to_thread(subprocess.run,command,input=json.dumps(current).encode(),capture_output=True,env=env,timeout=5)
            assert response.returncode==0
            value=json.loads(response.stdout)
            context=value.get('additionalContext') if host=='omp' else value['hookSpecificOutput']['additionalContext']
            assert 'AM_QA_9d7c_azure' in context
        # Real stdio MCP startup drains the captured candidates using actual Jev.
        parameters=StdioServerParameters(command=str(client_python),args=['-m','agents_memory_collab.cli','mcp','--connection',str(connection),
            '--state',str(state),'--project','synthetic-automation'],env=client_env if os.environ.get('AM_FRESH_CLIENT_PYTHON') else env)
        async with stdio_client(parameters) as (read,write),ClientSession(read,write) as session:
            initialized=await session.initialize()
            assert 'AM_QA_9d7c_azure' in initialized.instructions
            status=json.loads((await session.call_tool('setup_status',{})).content[0].text)
            assert status['ready']
            result=await session.call_tool('sync_retain',{'op_id':'f8bd4a0b-2c6e-4d90-bc91-66a6ded4ef2b','memory_id':'d733a901-c28b-49d1-928a-1ecef561a47d',
                'project':'synthetic-automation','text':'The synthetic background worker uses a ten-second polling interval.'})
            received=json.loads(result.content[0].text)
            assert received['state']=='received' and received['memory_ready'] is False
            # No sync_now call: this must be the actual background worker.
            for _ in range(100):
                state_result=json.loads((await session.call_tool('setup_status',{})).content[0].text)
                pending=state_result['replica']['pending']
                if all(item['status']=='needs_review' for item in pending):break
                await asyncio.sleep(.2)
            else:raise AssertionError('Automatic background drain did not converge: '+json.dumps(state_result))
            assert all(item['op_id']!='f8bd4a0b-2c6e-4d90-bc91-66a6ded4ef2b' for item in pending)
            recall=json.loads((await session.call_tool('recall',{'query':'polling interval','project':'synthetic-automation'})).content[0].text)
            assert any('ten-second' in m['text'] for m in recall['memories'])
        # Independent second replica and fresh process view.
        b=Replica(tmp_path/'second.sqlite',remote)
        await asyncio.to_thread(b.connect);await asyncio.to_thread(b.cycle)
        assert any('ten-second' in m['text'] for m in b.list_memories())
        evidence={'combined_runtime_started':True,'mode':'local','hindsight_internal_only':True,'gateway_contract':status['replica']['memory_contract'],
            'generated_clients':['claude','codex','omp'],'host_adapter_subprocesses_exercised':True,
            'actual_stdio_startup_context':True,'actual_jev_background_drain':True,'second_replica_applied':True,
            'native_interactive_host_trust':'not tested by this subprocess test','synthetic_only':True}
        (ROOT/'runtime-automation.json').write_text(json.dumps(evidence,indent=2)+'\n')
    finally:
        if a:a.close()
        if b:b.close()
        process.terminate()
        await asyncio.to_thread(process.wait,20)
