"""Headless host probes in generated, synthetic project configuration only."""
import asyncio
import json
import os
from pathlib import Path
import selectors
import signal
import sqlite3
import subprocess
import time
import tomllib
from uuid import uuid4

ROOT=Path(__file__).parent
QUESTION='What is the synthetic automation service verification marker? Reply with the marker from memory, or NO_MEMORY if unavailable.'
MARKER='AM_QA_9d7c_azure'


async def run_native(project,state,env):
    app_env=dict(env)
    app_env.pop('AM_MEMORY_JEV_KEY_FILE',None) # Clients never need the server's Jev credential selector.
    app_env.pop('PYTHONPATH',None) # Exercise the installed client wheel, not the test source overlay.
    result={}
    claude='/workspace/work/claude-cli/node_modules/.bin/claude'
    common=[claude,'-p','--model','claude-fable-5-1','--tools','','--strict-mcp-config','--mcp-config','{"mcpServers":{}}',
        '--setting-sources','','--no-session-persistence','--disable-slash-commands']
    for enabled in (True,False):
        settings=str(project/'.claude/settings.local.json') if enabled else '{"hooks":{}}'
        completed=await asyncio.to_thread(subprocess.run,[*common,'--settings',settings,QUESTION],cwd=project,env=app_env,
            capture_output=True,timeout=100)
        label='claude_hook' if enabled else 'claude_control'
        result[label]={'exit_code':completed.returncode,'marker_in_answer':MARKER in completed.stdout.decode(errors='replace')}
        (ROOT/(label+'-private.log')).write_bytes(completed.stdout+b'\n'+completed.stderr)
    # Prevent an MCP startup instruction from confounding the hook-only test.
    config=project/'.codex/config.toml'
    saved=config.read_bytes();config.write_text('# Synthetic hook-only project configuration\n')
    codex_home=Path(app_env.get('CODEX_HOME',str(Path.home()/'.codex')))
    profile='am-unified-qa-'+uuid4().hex
    profile_path=codex_home/(profile+'.config.toml')
    with os.fdopen(os.open(profile_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w') as stream:
        stream.write('[projects.'+json.dumps(str(project))+']\ntrust_level = "trusted"\n')
    base_config=codex_home/'config.toml'
    disabled_servers=[]
    if base_config.is_file():
        for name in tomllib.loads(base_config.read_text()).get('mcp_servers',{}):
            disabled_servers.extend(['-c','mcp_servers.'+json.dumps(name)+'.enabled=false'])
    try:
        common=['/opt/codex/bin/codex','exec','--ephemeral','--skip-git-repo-check','--sandbox','read-only',
            '-p',profile,'--ignore-rules','--dangerously-bypass-hook-trust',
            '--disable','apps','--disable','plugins','--disable','multi_agent','--disable','skill_search',
            '-c','mcp_servers={}','-c','features.shell_tool=false','-c','web_search="disabled"',
            '-c',f'projects."{project}".trust_level="trusted"',
            '--model','gpt-6.1-terra','--color','never',*disabled_servers]
        for enabled in (True,False):
            output=project/('codex-hook-answer.txt' if enabled else 'codex-control-answer.txt')
            command=[*common,'--enable' if enabled else '--disable','hooks','--output-last-message',str(output),QUESTION]
            completed=await asyncio.to_thread(subprocess.run,command,cwd=project,env=app_env,capture_output=True,timeout=120)
            answer=output.read_text() if output.exists() else ''
            label='codex_hook' if enabled else 'codex_control'
            result[label]={'exit_code':completed.returncode,'marker_in_answer':MARKER in answer,
                'trust':'one-invocation bypass for our generated and reviewed test hooks; normal first trust not tested'}
            (ROOT/(label+'-private.log')).write_bytes(completed.stdout+b'\n'+completed.stderr)
    finally:
        config.write_bytes(saved);config.chmod(0o600)
        profile_path.unlink()
    result['native_interactive_mac']='not tested'
    (ROOT/'native-hosts.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def omp_probe(project,state,env):
    home=project/'omp-synthetic-home';home.mkdir(mode=0o700,exist_ok=True)
    app_env=dict(env,HOME=str(home),PI_CODING_AGENT_DIR=str(home/'agent'),XDG_CACHE_HOME=str(home/'cache'))
    app_env.pop('AM_MEMORY_JEV_KEY_FILE',None)
    overlay=project/'omp-overlay.json'
    overlay.write_text(json.dumps({'tools':{'xdev':False},'mcp':{'enableProjectConfig':True}}))
    command=[str(ROOT/'tools/omp'),'--mode','rpc','--no-session','--no-extensions','--no-skills','--no-rules','--no-ui',
        '--no-tools','--model','openai/gpt-5.2','--api-key','synthetic-no-model-call','--config',str(overlay),
        '-e',str(project/'.omp/extensions/agents-memory-cloud.ts')]
    frames=[]
    with open(ROOT/'omp-private.log','wb') as log:
        process=subprocess.Popen(command,cwd=project,env=app_env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,start_new_session=True)
        try:
            process.stdin.write(json.dumps({'id':'memory-probe','type':'prompt','message':QUESTION})+'\n');process.stdin.flush()
            deadline=time.monotonic()+20
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout,selectors.EVENT_READ)
                while time.monotonic()<deadline:
                    if not selector.select(.5):continue
                    line=process.stdout.readline()
                    if not line:break
                    try:frame=json.loads(line)
                    except ValueError:continue
                    frames.append(frame)
                    if frame.get('type')=='agent_end':break
        finally:
            process.stdin.close()
            if process.poll() is None:os.killpg(process.pid,signal.SIGTERM)
            process.wait(timeout=10)
    with sqlite3.connect(state) as database:
        captured=any('host-omp:' in row[0] and 'verification marker' in row[0] for row in database.execute('SELECT body FROM outbox'))
    value={'omp_version':'18.16.0','native_before_agent_start_captured':captured,
        'extension_context_emitted':any('agents-memory.context' in json.dumps(frame) and MARKER in json.dumps(frame) for frame in frames),
        'outer_model_api':'deliberately invalid synthetic key; no claim of a successful model reply',
        'synthetic_only':True}
    (ROOT/'native-omp.json').write_text(json.dumps(value,indent=2)+'\n')
    return value
