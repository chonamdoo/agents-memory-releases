# Agents Memory MCP 2.0.5 (런타임 ABI 2.0.0)

로컬 설치는 로컬 LLM 또는 Jev를 선택합니다. 서버 설치는 Jev입니다.
공식 설치 안내: https://github.com/chonamdoo/agents-memory-releases/blob/v2.0.5/distribution/server/README.ko.md
배포·검증 범위: https://github.com/chonamdoo/agents-memory-releases/blob/main/release-candidates/v2.0.5-provider-choice/STATUS.json

먼저 공개 SHA256SUMS로 이 압축 파일을 검증하고 압축을 풉니다. 모델 companion은 v2.0.0 릴리즈의 기존 체크섬으로 검증합니다.
첫 설치에는 고정 genuine 1.0.2 bootstrap과 준비된 ONNX reranker 6파일이 필요합니다. 기존 설치는 소유 캐시를 재사용합니다.

```bash
# Ollama / LM Studio (설치된 모델 ID와 해당 서버의 /v1 주소 사용)
bash install-unified.sh --reranker-dir /absolute/model --mode local --provider local --local-host openai --model MODEL_ID --local-url http://127.0.0.1:11434/v1 --client omp-plugin --project "$PWD"
# 로그인된 Codex 구독 CLI: 로컬 실행, 업체 서버 추론
bash install-unified.sh --reranker-dir /absolute/model --mode local --provider local --local-host codex --model gpt-6.1-terra --client omp-plugin --project "$PWD"
# Jev: 키는 터미널 숨김 입력 또는 비공개 --jev-key-file
bash install-unified.sh --reranker-dir /absolute/model --mode local --provider jev --client omp-plugin --project "$PWD"
```

Claude 플러그인은 `--client claude-plugin`, Codex 프로젝트 MCP는 `--client codex`를 사용합니다.
로컬 최초 대화형 설치에서 공급자를 생략하면 선택 메뉴가 나옵니다. 자동 설치는 공급자를 명시하세요.
Claude 구독 CLI는 `--local-host claude --model claude-sonnet-5-5`입니다. 지원 플래그가 있는 최신 CLI와 사전 로그인이 필요합니다.
구독 CLI는 도구·MCP·규칙·세션 저장을 끕니다. API 키나 경로 우회 설정이 있으면 거절하며 API로 대체하지 않습니다.
서버는 `--mode personal-server|team-server|company-server --provider jev`를 사용합니다.

DB·키·대기 작업은 플러그인 캐시 밖에 보존합니다. 공급자 장애 시 다른 공급자로 대체하지 않습니다.
런타임 설치는 합성 입력으로 선택한 공급자를 한 번 확인합니다. 마켓 플러그인 설치 자체는 추론하지 않습니다.
v2.0.4의 Jev 독립 품질 근거는 그 버전의 기록입니다. 새 로컬 모델·구독 모델 품질은 별도 미측정입니다.
이번 검사는 프로토콜 대역을 사용한 기능 검사이며 실제 모델 추론 검사가 아닙니다. macOS는 사용자 실기기 테스트 대상입니다.
